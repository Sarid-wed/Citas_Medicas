package com.example.Citas_Medicas.service;

import com.example.Citas_Medicas.DTO.DoctorCreateDTO;
import com.example.Citas_Medicas.Entity.Doctor;
import com.example.Citas_Medicas.Entity.Especialidad;
import com.example.Citas_Medicas.repository.DoctorRepository;
import com.example.Citas_Medicas.repository.EspecialidadRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorService {
    @Autowired
    DoctorRepository repo;
    @Autowired
    EspecialidadRepository especialidadRepo;

    public List<Doctor> getAll() { return repo.findAll(); }

    public Doctor create(DoctorCreateDTO dto) {
        Doctor d = new Doctor();
        d.setDoctorName(dto.getDoctorName());
        d.setDoctorTarjetaProfesional(dto.getDoctorTarjetaProfesional());
        d.setDoctorTelefono(dto.getDoctorTelefono());
        d.setDoctorCorreo(dto.getDoctorCorreo());

        Especialidad esp = especialidadRepo.findById(dto.getEspecialidadId()).orElse(null);
        d.setEspecialidad(esp);

        return repo.save(d);
    }

    public void delete(Long id) { repo.deleteById(id); }
}
