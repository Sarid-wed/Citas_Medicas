package com.example.Citas_Medicas.repository;

import com.example.Citas_Medicas.Entity.Especialidad;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EspecialidadRepository extends JpaRepository<Especialidad, Long> {
}
