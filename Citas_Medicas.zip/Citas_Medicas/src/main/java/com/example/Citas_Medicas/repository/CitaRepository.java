package com.example.Citas_Medicas.repository;

import com.example.Citas_Medicas.Entity.Cita_Medica;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CitaRepository extends JpaRepository<Cita_Medica, Long> {
    List<Cita_Medica> findByPacientePacienteId(Long pacienteId);
    List<Cita_Medica> findByDoctorDoctorId(Long doctorId);
}
