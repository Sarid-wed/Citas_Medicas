package com.example.Citas_Medicas.repository;

import com.example.Citas_Medicas.Entity.Doctor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {
}
