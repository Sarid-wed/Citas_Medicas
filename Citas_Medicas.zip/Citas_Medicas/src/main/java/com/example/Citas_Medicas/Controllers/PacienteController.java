package com.example.Citas_Medicas.Controllers;

import com.example.Citas_Medicas.Entity.Paciente;
import com.example.Citas_Medicas.service.PacienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/paciente")
public class PacienteController {


    @Autowired
    private PacienteService service;

    @GetMapping
    public List<Paciente> getAll() { return service.getAll(); }

    @GetMapping("/{id}")
    public Paciente getById(@PathVariable Long id) { return service.getById(id); }

    @PostMapping
    public Paciente create(@RequestBody Paciente p) { return service.create(p); }

    @PutMapping("/{id}")
    public Paciente update(@PathVariable Long id, @RequestBody Paciente p) { return service.update(id, p); }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { service.delete(id); }
}
