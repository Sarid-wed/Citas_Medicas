package com.example.Citas_Medicas.Entity;


import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "doctor")
@Data
public class Doctor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "doctor_id")
    private Long doctorId;

    @Column(name = "doctor_name", nullable = false, length = 50)
    private String doctorName;

    @Column(name = "doctor_tarjetaProfesional", nullable = false, length = 50)
    private String doctorTarjetaProfesional;

    @Column(name = "doctor_telefono", nullable = false, length = 50)
    private String doctorTelefono;

    @Column(name = "doctor_correo", nullable = false, length = 50)
    private String doctorCorreo;

    @ManyToOne
    @JoinColumn(name = "especialidad_id")
    private Especialidad especialidad;
}