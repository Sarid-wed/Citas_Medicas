package com.example.Citas_Medicas.repository;

import com.example.Citas_Medicas.Entity.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PacienteRepository extends JpaRepository<Paciente, Long> {
}
