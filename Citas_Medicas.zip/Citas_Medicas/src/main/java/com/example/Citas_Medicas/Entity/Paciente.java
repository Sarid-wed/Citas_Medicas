package com.example.Citas_Medicas.Entity;

import jakarta.persistence.*;
import lombok.Data;


@Entity
@Table(name = "paciente")
@Data
public class Paciente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column (name = "paciente_id")
    private long pacienteId;

    @Column (name = "paciente_name", nullable = false, length = 50)
    private String pacienteName;

    @Column (name = "paciente_documento", nullable = false, length = 50)
    private Number pacienteDocumento;

    @Column (name = "paciente_telefono", nullable = false, length = 50)
    private Number pacienteTelefono;

    @Column (name = "paciente_correo", nullable = false, length = 50)
    private String pacienteCorreo;

    @Column (name = "paciente_direccion", nullable = false, length = 50)
    private String pacienteDireccion;
}