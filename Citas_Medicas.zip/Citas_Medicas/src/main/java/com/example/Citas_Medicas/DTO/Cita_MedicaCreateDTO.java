package com.example.Citas_Medicas.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Cita_MedicaCreateDTO {
    private Long pacienteId;
    private Long doctorId;
    private String fecha;
    private String hora;
    private String motivo;

}
