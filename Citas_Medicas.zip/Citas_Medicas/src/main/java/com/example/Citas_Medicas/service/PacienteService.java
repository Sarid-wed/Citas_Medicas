package com.example.Citas_Medicas.service;

import com.example.Citas_Medicas.Entity.Paciente;
import com.example.Citas_Medicas.repository.PacienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PacienteService {

    @Autowired
    private PacienteRepository repo;

    public List<Paciente> getAll() { return repo.findAll(); }

    public Paciente getById(Long id) { return repo.findById(id).orElse(null); }

    public Paciente create(Paciente p) { return repo.save(p); }

    public Paciente update(Long id, Paciente data) {
        Paciente p = getById(id);
        if (p == null) return null;

        p.setPacienteName(data.getPacienteName());
        p.setPacienteDocumento(data.getPacienteDocumento());
        p.setPacienteTelefono(data.getPacienteTelefono());
        p.setPacienteCorreo(data.getPacienteCorreo());
        p.setPacienteDireccion(data.getPacienteDireccion());

        return repo.save(p);
    }

    public void delete(Long id) { repo.deleteById(id); }
}
