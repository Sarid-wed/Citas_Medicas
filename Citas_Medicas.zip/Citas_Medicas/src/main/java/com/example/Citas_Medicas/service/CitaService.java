package com.example.Citas_Medicas.service;

import com.example.Citas_Medicas.DTO.Cita_MedicaCreateDTO;
import com.example.Citas_Medicas.Entity.Cita_Medica;
import com.example.Citas_Medicas.Entity.Doctor;
import com.example.Citas_Medicas.Entity.Paciente;
import com.example.Citas_Medicas.repository.CitaRepository;
import com.example.Citas_Medicas.repository.DoctorRepository;
import com.example.Citas_Medicas.repository.PacienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CitaService {

    @Autowired
    CitaRepository repo;
    @Autowired
    PacienteRepository pacienteRepo;
    @Autowired
    DoctorRepository doctorRepo;

    public List<Cita_Medica> getAll() { return repo.findAll(); }

    public Cita_Medica create(Cita_MedicaCreateDTO dto) {

        Paciente p = pacienteRepo.findById(dto.getPacienteId()).orElse(null);
        Doctor d = doctorRepo.findById(dto.getDoctorId()).orElse(null);

        Cita_Medica c = new Cita_Medica();
        c.setFecha(dto.getFecha());
        c.setHora(dto.getHora());
        c.setMotivo(dto.getMotivo());

        c.setPaciente(p);
        c.setDoctor(d);

        return repo.save(c);
    }

    public void delete(Long id) { repo.deleteById(id); }

    public List<Cita_Medica> citasPorPaciente(Long id) {
        return repo.findByPacientePacienteId(id);
    }

    public List<Cita_Medica> citasPorDoctor(Long id) {
        return repo.findByDoctorDoctorId(id);
    }
}
