package com.example.Citas_Medicas.Controllers;

import com.example.Citas_Medicas.DTO.DoctorCreateDTO;
import com.example.Citas_Medicas.Entity.Doctor;
import com.example.Citas_Medicas.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/Doctor")
public class DoctorController {

    @Autowired
    private DoctorService service;

    @GetMapping
    public List<Doctor> getAll() { return service.getAll(); }

    @PostMapping
    public Doctor create(@RequestBody DoctorCreateDTO dto) { return service.create(dto); }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { service.delete(id); }
}