package com.example.Citas_Medicas.Controllers;

import com.example.Citas_Medicas.DTO.Cita_MedicaCreateDTO;
import com.example.Citas_Medicas.Entity.Cita_Medica;
import com.example.Citas_Medicas.service.CitaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cita")
public class CitaController {

    @Autowired
    private CitaService service;

    @GetMapping
    public List<Cita_Medica> getAll() { return service.getAll(); }

    @PostMapping
    public Cita_Medica create(@RequestBody Cita_MedicaCreateDTO dto) { return service.create(dto); }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { service.delete(id); }

    // Citas por paciente
    @GetMapping("/paciente/{id}")
    public List<Cita_Medica> citasPorPaciente(@PathVariable Long id) {
        return service.citasPorPaciente(id);
    }

    // Citas por doctor
    @GetMapping("/doctor/{id}")
    public List<Cita_Medica> citasPorDoctor(@PathVariable Long id) {
        return service.citasPorDoctor(id);
    }
}
