package com.example.Citas_Medicas.service;

import com.example.Citas_Medicas.Entity.Especialidad;
import com.example.Citas_Medicas.repository.EspecialidadRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EspecialidadService {
    @Autowired
    private EspecialidadRepository repo;

    public List<Especialidad> getAll(Integer limit) {
        List<Especialidad> lista = repo.findAll();
        if (limit != null && limit < lista.size())
            return lista.subList(0, limit);
        return lista;
    }

    public Especialidad create(Especialidad e) { return repo.save(e); }
    public Especialidad update(Long id, Especialidad e) {
        Especialidad esp = repo.findById(id).orElse(null);
        if (esp == null) return null;

        esp.setEspecialidadName(e.getEspecialidadName());
        esp.setEspecialidadDescripcion(e.getEspecialidadDescripcion());
        return repo.save(esp);
    }

    public void delete(Long id) { repo.deleteById(id); }
}
