package com.example.Citas_Medicas.Controllers;

import com.example.Citas_Medicas.Entity.Especialidad;
import com.example.Citas_Medicas.service.EspecialidadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/especialidad")
public class EspecialidadController {
    @Autowired
    private EspecialidadService service;

    @GetMapping
    public List<Especialidad> getAll(@RequestParam(required = false) Integer limit) {
        return service.getAll(limit);
    }

    @PostMapping
    public Especialidad create(@RequestBody Especialidad e) { return service.create(e); }

    @PutMapping("/{id}")
    public Especialidad update(@PathVariable Long id, @RequestBody Especialidad e) { return service.update(id, e); }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) { service.delete(id); }
}
