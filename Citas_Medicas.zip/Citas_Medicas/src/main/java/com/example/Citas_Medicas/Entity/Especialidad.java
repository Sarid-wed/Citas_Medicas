package com.example.Citas_Medicas.Entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "especialidad")
@Data
public class Especialidad {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long especialidadId;

    @Column(nullable = false, length = 50)
    private String especialidadName;

    @Column(nullable = false, length = 200)
    private String especialidadDescripcion;
}