package com.example.Citas_Medicas.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DoctorCreateDTO {
    private String doctorName;
    private String doctorTarjetaProfesional;
    private String doctorTelefono;
    private String doctorCorreo;
    private Long especialidadId;
}
