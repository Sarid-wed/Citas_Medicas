package com.example.Citas_Medicas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitasMedicasApplicationTests {

	@Test
	void contextLoads() {
	}

}
